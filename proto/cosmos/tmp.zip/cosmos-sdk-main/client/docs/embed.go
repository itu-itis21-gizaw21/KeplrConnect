package docs

import "embed"

//go:embed swagger-ui
var SwaggerUI embed.FS
